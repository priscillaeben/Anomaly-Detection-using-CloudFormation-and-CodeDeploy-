#!/bin/bash


sudo python3 raw_data.py
