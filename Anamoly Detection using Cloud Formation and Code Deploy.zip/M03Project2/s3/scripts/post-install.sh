#!/bin/bash

echo "It is done"